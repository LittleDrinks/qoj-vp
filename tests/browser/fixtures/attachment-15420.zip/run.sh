#!/bin/sh
# SYNTHETIC FIXTURE ONLY. Do not execute attachments.
